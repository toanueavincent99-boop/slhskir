import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "SLHS Kiribati - Excellence in Education",
  description: "Saint Louis High School Kiribati - Empowering students with knowledge, character, and excellence in the heart of the Pacific. Mauri!",
  keywords: ["SLHS Kiribati", "Saint Louis High School", "Kiribati", "Education", "Pacific Islands", "School"],
  authors: [{ name: "SLHS Kiribati" }],
  icons: {
    icon: "/favicon.ico",
  },
  openGraph: {
    title: "SLHS Kiribati - Excellence in Education",
    description: "Saint Louis High School Kiribati - Empowering students with knowledge, character, and excellence",
    url: "https://slhskiribati.edu.ki",
    siteName: "SLHS Kiribati",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "SLHS Kiribati - Excellence in Education",
    description: "Saint Louis High School Kiribati - Empowering students in the Pacific",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
