# SLHS Kiribati School Website

A professional, responsive school website for Saint Louis High School Kiribati.

## Features

- **Responsive Design** - Works on mobile, tablet, and desktop
- **Hero Section** - Beautiful school banner with welcome message
- **About Section** - School information and statistics
- **Top Students** - Showcase of outstanding students with photos
- **Study Resources** - Downloadable notes and video tutorials
- **Mission & Vision** - School values and goals
- **Contact Information** - Address, email, and phone

## Tech Stack

- **Next.js 15** - React framework
- **TypeScript** - Type-safe JavaScript
- **Tailwind CSS** - Utility-first CSS framework
- **shadcn/ui** - Beautiful UI components

---

## Deployment Guide

### Option 1: Deploy to Vercel (Recommended - FREE)

#### Step 1: Create Vercel Account
1. Go to [vercel.com](https://vercel.com)
2. Click "Sign Up"
3. Choose "Continue with GitHub" or "Continue with Google"

#### Step 2: Install Vercel CLI (Optional)
```bash
npm install -g vercel
```

#### Step 3: Deploy
**Method A: Drag & Drop (Easiest)**
1. Go to [vercel.com/new](https://vercel.com/new)
2. Drag and drop this entire `slhs-kiribati-website` folder
3. Wait for deployment to complete
4. Get your free URL (e.g., `slhs-kiribati.vercel.app`)

**Method B: Using CLI**
```bash
cd slhs-kiribati-website
vercel
```

#### Step 4: Custom Domain (Optional)
1. Go to your project settings on Vercel
2. Click "Domains"
3. Add your custom domain (e.g., `www.slhskiribati.edu.ki`)

---

### Option 2: Deploy to Netlify (FREE)

1. Go to [netlify.com](https://netlify.com)
2. Sign up for free
3. Drag and drop the project folder
4. Get your free URL

---

### Option 3: Run Locally

```bash
# Navigate to project folder
cd slhs-kiribati-website

# Install dependencies
npm install

# Run development server
npm run dev

# Open http://localhost:3000 in your browser
```

---

## Project Structure

```
slhs-kiribati-website/
├── public/
│   └── images/
│       ├── hero-school.png    # Hero banner image
│       ├── student1.png       # Student photo
│       ├── student2.png       # Student photo
│       └── student3.png       # Student photo
├── src/
│   ├── app/
│   │   ├── page.tsx          # Main page (all sections)
│   │   ├── layout.tsx        # Root layout
│   │   └── globals.css       # Global styles
│   ├── components/ui/        # UI components
│   ├── hooks/                # React hooks
│   └── lib/                  # Utility functions
├── package.json              # Dependencies
├── tailwind.config.ts        # Tailwind configuration
├── tsconfig.json             # TypeScript configuration
└── next.config.ts            # Next.js configuration
```

---

## Customization Guide

### Change Student Names
Edit `src/app/page.tsx` and find the `topStudents` array:

```typescript
const topStudents = [
  {
    id: 1,
    name: "Your Student Name",
    grade: "Year 12",
    achievement: "Award Name",
    image: "/images/student1.png"
  },
  // ... more students
]
```

### Add Study Resources
Edit `src/app/page.tsx` and find the `studyResources` array:

```typescript
const studyResources = [
  {
    id: 1,
    subject: "Mathematics",
    notes: [
      {
        id: 1,
        title: "Your Note Title",
        description: "Description",
        year: "Year 9-10",
        size: "2.5 MB"
      },
    ],
    // ...
  }
]
```

### Add Downloadable Files
1. Create folder: `public/downloads/`
2. Add your PDF files there
3. Update the download links in `page.tsx`:

```typescript
href="/downloads/your-file.pdf"
```

### Replace Images
1. Add new images to `public/images/`
2. Update the image paths in `page.tsx`

---

## Support

For help or questions, contact your school IT administrator.

---

## License

© 2024 Saint Louis High School Kiribati. All rights reserved.
