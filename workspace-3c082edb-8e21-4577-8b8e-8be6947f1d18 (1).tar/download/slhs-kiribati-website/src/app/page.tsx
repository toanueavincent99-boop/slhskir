'use client'

import Image from 'next/image'
import { useState } from 'react'

// Top Students Data
const topStudents = [
  {
    id: 1,
    name: "Tiita Bwebwe",
    grade: "Year 12",
    achievement: "Academic Excellence Award 2024",
    image: "/images/student1.png"
  },
  {
    id: 2,
    name: "Riiki Tione",
    grade: "Year 11",
    achievement: "Science Olympiad Winner",
    image: "/images/student2.png"
  },
  {
    id: 3,
    name: "Nei Tabera",
    grade: "Year 12",
    achievement: "Mathematics Champion",
    image: "/images/student3.png"
  },
  {
    id: 4,
    name: "Bauro Ioane",
    grade: "Year 13",
    achievement: "Valedictorian 2024",
    image: "/images/student2.png"
  },
  {
    id: 5,
    name: "Teraai Moan",
    grade: "Year 11",
    achievement: "Outstanding Leadership",
    image: "/images/student1.png"
  },
  {
    id: 6,
    name: "Berenika Toau",
    grade: "Year 12",
    achievement: "Arts & Culture Award",
    image: "/images/student3.png"
  }
]

// Study Resources Data
const studyResources = [
  {
    id: 1,
    subject: "Mathematics",
    icon: "📐",
    color: "from-blue-500 to-blue-600",
    notes: [
      { id: 1, title: "Algebra Fundamentals", description: "Basic algebraic expressions and equations", year: "Year 9-10", size: "2.5 MB" },
      { id: 2, title: "Calculus Introduction", description: "Derivatives and integrals basics", year: "Year 12-13", size: "3.8 MB" },
      { id: 3, title: "Geometry & Trigonometry", description: "Shapes, angles and trigonometric functions", year: "Year 10-11", size: "4.2 MB" },
    ],
    videos: [
      { id: 1, title: "Solving Quadratic Equations", duration: "15:30", views: "1.2K" },
      { id: 2, title: "Understanding Functions", duration: "12:45", views: "890" },
    ]
  },
  {
    id: 2,
    subject: "Science",
    icon: "🔬",
    color: "from-green-500 to-green-600",
    notes: [
      { id: 1, title: "Biology: Cell Structure", description: "Introduction to cell biology", year: "Year 9-10", size: "5.1 MB" },
      { id: 2, title: "Chemistry: Periodic Table", description: "Elements and compounds", year: "Year 10-11", size: "3.2 MB" },
      { id: 3, title: "Physics: Motion & Forces", description: "Newton's laws and motion", year: "Year 11-12", size: "4.5 MB" },
    ],
    videos: [
      { id: 1, title: "Photosynthesis Explained", duration: "18:20", views: "2.1K" },
      { id: 2, title: "Chemical Reactions", duration: "14:15", views: "1.5K" },
    ]
  },
  {
    id: 3,
    subject: "English",
    icon: "📚",
    color: "from-purple-500 to-purple-600",
    notes: [
      { id: 1, title: "Essay Writing Guide", description: "How to write effective essays", year: "Year 9-13", size: "1.8 MB" },
      { id: 2, title: "Grammar Essentials", description: "Punctuation and sentence structure", year: "Year 9-10", size: "2.1 MB" },
      { id: 3, title: "Literature Analysis", description: "Analyzing novels and poems", year: "Year 11-13", size: "3.4 MB" },
    ],
    videos: [
      { id: 1, title: "Creative Writing Tips", duration: "10:45", views: "750" },
      { id: 2, title: "Shakespeare Made Easy", duration: "22:30", views: "1.8K" },
    ]
  },
  {
    id: 4,
    subject: "Social Studies",
    icon: "🌍",
    color: "from-orange-500 to-orange-600",
    notes: [
      { id: 1, title: "Kiribati History", description: "History and culture of Kiribati", year: "Year 9-10", size: "4.0 MB" },
      { id: 2, title: "Pacific Geography", description: "Islands and climate of the Pacific", year: "Year 10-11", size: "3.7 MB" },
      { id: 3, title: "Civics & Government", description: "Understanding government systems", year: "Year 11-12", size: "2.9 MB" },
    ],
    videos: [
      { id: 1, title: "Pacific Island Nations", duration: "16:00", views: "620" },
      { id: 2, title: "Climate Change in Kiribati", duration: "20:15", views: "1.3K" },
    ]
  }
]

// Active tab type
type TabType = 'notes' | 'videos'

export default function Home() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [activeSubject, setActiveSubject] = useState(studyResources[0])
  const [activeTab, setActiveTab] = useState<TabType>('notes')

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="bg-gradient-to-r from-blue-900 via-blue-800 to-teal-700 text-white sticky top-0 z-50 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16 md:h-20">
            {/* Logo */}
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 md:w-12 md:h-12 bg-yellow-400 rounded-full flex items-center justify-center">
                <span className="text-blue-900 font-bold text-lg md:text-xl">S</span>
              </div>
              <div>
                <h1 className="text-xl md:text-2xl font-bold tracking-tight">SLHS Kiribati</h1>
                <p className="text-xs md:text-sm text-blue-200 hidden sm:block">Excellence in Education</p>
              </div>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center gap-8">
              <a href="#home" className="hover:text-yellow-400 transition-colors font-medium">Home</a>
              <a href="#about" className="hover:text-yellow-400 transition-colors font-medium">About</a>
              <a href="#students" className="hover:text-yellow-400 transition-colors font-medium">Top Students</a>
              <a href="#resources" className="hover:text-yellow-400 transition-colors font-medium">Resources</a>
              <a href="#contact" className="hover:text-yellow-400 transition-colors font-medium">Contact</a>
            </div>

            {/* Mobile Menu Button */}
            <button 
              className="md:hidden p-2"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                {mobileMenuOpen ? (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                ) : (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                )}
              </svg>
            </button>
          </div>

          {/* Mobile Navigation */}
          {mobileMenuOpen && (
            <div className="md:hidden pb-4 space-y-2">
              <a href="#home" className="block py-2 px-4 hover:bg-blue-700 rounded transition-colors">Home</a>
              <a href="#about" className="block py-2 px-4 hover:bg-blue-700 rounded transition-colors">About</a>
              <a href="#students" className="block py-2 px-4 hover:bg-blue-700 rounded transition-colors">Top Students</a>
              <a href="#resources" className="block py-2 px-4 hover:bg-blue-700 rounded transition-colors">Resources</a>
              <a href="#contact" className="block py-2 px-4 hover:bg-blue-700 rounded transition-colors">Contact</a>
            </div>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section id="home" className="relative h-[60vh] md:h-[80vh] overflow-hidden">
        <Image
          src="/images/hero-school.png"
          alt="SLHS Kiribati School Campus"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-t from-blue-900/80 via-blue-900/40 to-transparent" />
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center text-white px-4 max-w-4xl">
            <h2 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-4 drop-shadow-lg">
              Mauri!
            </h2>
            <p className="text-xl md:text-2xl lg:text-3xl mb-2 font-light">
              Welcome to SLHS Kiribati
            </p>
            <p className="text-base md:text-lg text-blue-200 mb-8 max-w-2xl mx-auto">
              Empowering students with knowledge, character, and excellence in the heart of the Pacific
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a 
                href="#students" 
                className="inline-block bg-yellow-400 text-blue-900 font-bold px-6 py-3 md:px-8 md:py-4 rounded-full hover:bg-yellow-300 transition-all transform hover:scale-105 shadow-lg"
              >
                Meet Our Top Students
              </a>
              <a 
                href="#resources" 
                className="inline-block bg-white/20 backdrop-blur-sm text-white font-bold px-6 py-3 md:px-8 md:py-4 rounded-full hover:bg-white/30 transition-all transform hover:scale-105 shadow-lg border border-white/30"
              >
                Download Study Materials
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-16 md:py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">About Our School</h2>
            <div className="w-24 h-1 bg-yellow-400 mx-auto rounded-full"></div>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8 md:gap-12 items-center">
            <div className="space-y-6">
              <p className="text-gray-700 text-lg leading-relaxed">
                Saint Louis High School (SLHS) Kiribati stands as a beacon of educational excellence in the Pacific region. 
                Our institution has been nurturing young minds and building future leaders who contribute meaningfully 
                to Kiribati and the global community.
              </p>
              <p className="text-gray-700 text-lg leading-relaxed">
                With dedicated teachers, modern facilities, and a commitment to holistic education, we ensure that 
                every student receives the support they need to excel academically and personally.
              </p>
              <div className="grid grid-cols-2 gap-4 pt-4">
                <div className="text-center p-4 bg-white rounded-lg shadow-md">
                  <p className="text-3xl md:text-4xl font-bold text-blue-800">500+</p>
                  <p className="text-gray-600 text-sm">Students</p>
                </div>
                <div className="text-center p-4 bg-white rounded-lg shadow-md">
                  <p className="text-3xl md:text-4xl font-bold text-blue-800">40+</p>
                  <p className="text-gray-600 text-sm">Teachers</p>
                </div>
                <div className="text-center p-4 bg-white rounded-lg shadow-md">
                  <p className="text-3xl md:text-4xl font-bold text-blue-800">25+</p>
                  <p className="text-gray-600 text-sm">Years of Excellence</p>
                </div>
                <div className="text-center p-4 bg-white rounded-lg shadow-md">
                  <p className="text-3xl md:text-4xl font-bold text-blue-800">98%</p>
                  <p className="text-gray-600 text-sm">Graduation Rate</p>
                </div>
              </div>
            </div>
            <div className="relative h-64 md:h-96 rounded-2xl overflow-hidden shadow-2xl">
              <Image
                src="/images/hero-school.png"
                alt="School Campus"
                fill
                className="object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Top Students Section */}
      <section id="students" className="py-16 md:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Our Top Students</h2>
            <div className="w-24 h-1 bg-yellow-400 mx-auto rounded-full mb-4"></div>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Celebrating our outstanding achievers who demonstrate exceptional academic performance, 
              leadership, and commitment to excellence.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {topStudents.map((student, index) => (
              <div 
                key={student.id}
                className="bg-white rounded-2xl shadow-lg overflow-hidden transform transition-all duration-300 hover:scale-105 hover:shadow-xl border border-gray-100"
              >
                <div className="relative h-48 md:h-64">
                  <Image
                    src={student.image}
                    alt={student.name}
                    fill
                    className="object-cover"
                  />
                  <div className="absolute top-4 left-4">
                    <span className="bg-yellow-400 text-blue-900 font-bold px-3 py-1 rounded-full text-sm">
                      #{index + 1}
                    </span>
                  </div>
                </div>
                <div className="p-5 md:p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-1">{student.name}</h3>
                  <p className="text-blue-600 font-medium mb-2">{student.grade}</p>
                  <div className="flex items-center gap-2">
                    <svg className="w-5 h-5 text-yellow-500" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                    <span className="text-gray-700 text-sm">{student.achievement}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Resources & Downloads Section */}
      <section id="resources" className="py-16 md:py-24 bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Study Resources</h2>
            <div className="w-24 h-1 bg-yellow-400 mx-auto rounded-full mb-4"></div>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Download study notes and watch video tutorials to help with your studies. 
              All resources are free for SLHS students.
            </p>
          </div>

          <div className="grid lg:grid-cols-4 gap-6">
            {/* Subject Sidebar */}
            <div className="lg:col-span-1">
              <div className="bg-white rounded-2xl shadow-lg p-4 sticky top-24">
                <h3 className="font-bold text-gray-900 mb-4 px-2">Subjects</h3>
                <div className="space-y-2">
                  {studyResources.map((resource) => (
                    <button
                      key={resource.id}
                      onClick={() => setActiveSubject(resource)}
                      className={`w-full text-left px-4 py-3 rounded-xl transition-all ${
                        activeSubject.id === resource.id
                          ? `bg-gradient-to-r ${resource.color} text-white shadow-md`
                          : 'hover:bg-gray-100 text-gray-700'
                      }`}
                    >
                      <span className="mr-2">{resource.icon}</span>
                      {resource.subject}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Resources Content */}
            <div className="lg:col-span-3">
              <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
                {/* Subject Header */}
                <div className={`bg-gradient-to-r ${activeSubject.color} p-6 text-white`}>
                  <div className="flex items-center gap-3">
                    <span className="text-4xl">{activeSubject.icon}</span>
                    <div>
                      <h3 className="text-2xl font-bold">{activeSubject.subject}</h3>
                      <p className="text-white/80">Study materials and video tutorials</p>
                    </div>
                  </div>
                </div>

                {/* Tabs */}
                <div className="border-b border-gray-200">
                  <div className="flex">
                    <button
                      onClick={() => setActiveTab('notes')}
                      className={`flex-1 py-4 px-6 font-medium transition-all ${
                        activeTab === 'notes'
                          ? 'text-blue-600 border-b-2 border-blue-600 bg-blue-50'
                          : 'text-gray-500 hover:text-gray-700'
                      }`}
                    >
                      <span className="flex items-center justify-center gap-2">
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                        </svg>
                        Download Notes
                      </span>
                    </button>
                    <button
                      onClick={() => setActiveTab('videos')}
                      className={`flex-1 py-4 px-6 font-medium transition-all ${
                        activeTab === 'videos'
                          ? 'text-blue-600 border-b-2 border-blue-600 bg-blue-50'
                          : 'text-gray-500 hover:text-gray-700'
                      }`}
                    >
                      <span className="flex items-center justify-center gap-2">
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        Video Tutorials
                      </span>
                    </button>
                  </div>
                </div>

                {/* Content */}
                <div className="p-6">
                  {activeTab === 'notes' ? (
                    <div className="space-y-4">
                      {activeSubject.notes.map((note) => (
                        <div 
                          key={note.id}
                          className="flex flex-col sm:flex-row sm:items-center justify-between p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-all gap-4"
                        >
                          <div className="flex items-start gap-4">
                            <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center flex-shrink-0">
                              <svg className="w-6 h-6 text-red-600" fill="currentColor" viewBox="0 0 20 20">
                                <path fillRule="evenodd" d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4z" clipRule="evenodd" />
                              </svg>
                            </div>
                            <div>
                              <h4 className="font-semibold text-gray-900">{note.title}</h4>
                              <p className="text-sm text-gray-600">{note.description}</p>
                              <div className="flex gap-3 mt-1">
                                <span className="text-xs text-blue-600 font-medium">{note.year}</span>
                                <span className="text-xs text-gray-400">•</span>
                                <span className="text-xs text-gray-500">{note.size}</span>
                              </div>
                            </div>
                          </div>
                          <a
                            href="#"
                            onClick={(e) => {
                              e.preventDefault()
                              alert(`Downloading: ${note.title}\n\nIn production, this would download the PDF file.`)
                            }}
                            className="inline-flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-all text-sm font-medium whitespace-nowrap"
                          >
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                            </svg>
                            Download
                          </a>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="grid sm:grid-cols-2 gap-4">
                      {activeSubject.videos.map((video) => (
                        <div 
                          key={video.id}
                          className="bg-gray-50 rounded-xl overflow-hidden hover:shadow-md transition-all"
                        >
                          <div className="relative h-40 bg-gradient-to-br from-gray-700 to-gray-900 flex items-center justify-center">
                            <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm cursor-pointer hover:bg-white/30 transition-all">
                              <svg className="w-8 h-8 text-white ml-1" fill="currentColor" viewBox="0 0 20 20">
                                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd" />
                              </svg>
                            </div>
                            <div className="absolute bottom-2 right-2 bg-black/70 text-white text-xs px-2 py-1 rounded">
                              {video.duration}
                            </div>
                          </div>
                          <div className="p-4">
                            <h4 className="font-semibold text-gray-900 mb-1">{video.title}</h4>
                            <div className="flex items-center gap-2 text-sm text-gray-500">
                              <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                                <path d="M10 12a2 2 0 100-4 2 2 0 000 4z" />
                                <path fillRule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clipRule="evenodd" />
                              </svg>
                              {video.views} views
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Help Box */}
                <div className="bg-yellow-50 border-t border-yellow-200 p-4">
                  <div className="flex items-start gap-3">
                    <svg className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                    </svg>
                    <div>
                      <p className="text-sm text-yellow-800">
                        <strong>Need help?</strong> Contact your teacher or visit the school library for additional study materials.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mission & Vision Section */}
      <section className="py-16 md:py-24 bg-gradient-to-r from-blue-900 via-blue-800 to-teal-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-8 md:gap-12">
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 md:p-8">
              <div className="w-16 h-16 bg-yellow-400 rounded-full flex items-center justify-center mb-6">
                <svg className="w-8 h-8 text-blue-900" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <h3 className="text-2xl font-bold mb-4">Our Mission</h3>
              <p className="text-blue-100 leading-relaxed">
                To provide quality education that empowers students with knowledge, skills, and values 
                necessary to become responsible citizens and future leaders who contribute positively 
                to Kiribati and the world.
              </p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 md:p-8">
              <div className="w-16 h-16 bg-yellow-400 rounded-full flex items-center justify-center mb-6">
                <svg className="w-8 h-8 text-blue-900" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                </svg>
              </div>
              <h3 className="text-2xl font-bold mb-4">Our Vision</h3>
              <p className="text-blue-100 leading-relaxed">
                To be the leading educational institution in the Pacific, recognized for producing 
                graduates who excel academically, demonstrate strong moral character, and serve 
                as catalysts for positive change in their communities.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-16 md:py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Contact Us</h2>
            <div className="w-24 h-1 bg-yellow-400 mx-auto rounded-full"></div>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center p-6 bg-white rounded-xl shadow-md">
              <div className="w-14 h-14 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-7 h-7 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
              </div>
              <h3 className="font-bold text-gray-900 mb-2">Address</h3>
              <p className="text-gray-600">South Tarawa, Kiribati</p>
            </div>
            <div className="text-center p-6 bg-white rounded-xl shadow-md">
              <div className="w-14 h-14 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-7 h-7 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                </svg>
              </div>
              <h3 className="font-bold text-gray-900 mb-2">Email</h3>
              <p className="text-gray-600">info@slhskiribati.edu.ki</p>
            </div>
            <div className="text-center p-6 bg-white rounded-xl shadow-md">
              <div className="w-14 h-14 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-7 h-7 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                </svg>
              </div>
              <h3 className="font-bold text-gray-900 mb-2">Phone</h3>
              <p className="text-gray-600">+686 75012XXX</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8 md:py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-yellow-400 rounded-full flex items-center justify-center">
                <span className="text-blue-900 font-bold text-lg">S</span>
              </div>
              <span className="text-xl font-bold">SLHS Kiribati</span>
            </div>
            <p className="text-gray-400 text-sm text-center md:text-right">
              &copy; {new Date().getFullYear()} Saint Louis High School Kiribati. All rights reserved.
            </p>
          </div>
          <div className="mt-6 pt-6 border-t border-gray-800 text-center">
            <p className="text-gray-500 text-sm">
              "Mauri" - Empowering the Future of Kiribati
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}
